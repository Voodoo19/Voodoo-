if __name__ == '__main__':
    import plugin
    plugin.main()
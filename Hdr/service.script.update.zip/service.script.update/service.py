# -*- coding: utf-8 -*-
import os
import sys
import six
import shutil
import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon
from six.moves import urllib_request, urllib_parse, urllib_error, http_cookiejar, html_parser
from xml.etree import ElementTree

try:
    from xbmcvfs import translatePath
except ImportError:
    from xbmc import translatePath

url = 'https://raw.githubusercontent.com/Voodoo19/Voodoo-/master/Hdr/TV/settings.xml'

AddonID = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(id=AddonID)
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
addondir = translatePath(os.path.join('special://home/addons/'))

dst = translatePath(os.path.join('special://home/addons/plugin.video.helvete-tv/resources/settings.xml'))
dst1 = translatePath(os.path.join('special://home/temp/settings.xml'))
dst2 = translatePath(os.path.join('special://home/media/settings.xml'))


scr = translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.xstream/settings.xml'))
scr1 = translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.xship/settings.xml'))

try:

		line=urllib_request.urlopen(url).read()

		with open(dst, 'w+') if six.PY2 else open(dst,'w+', encoding='utf-8') as f:

			content = f.read()

			f.write(line.decode('utf-8').replace('', '') + content)

			f.close()

			xbmc.sleep(1000)
			if  os.path.exists(scr):shutil.copy(scr, dst1)
			if os.path.exists(scr1):shutil.copy(scr1, dst2)
			if not os.path.exists(scr):shutil.copy(dst1, scr)
			if not os.pathexits(scr1):shutil.copy(dst2, scr1)

except:

									pass

									

									

										

		

			


        












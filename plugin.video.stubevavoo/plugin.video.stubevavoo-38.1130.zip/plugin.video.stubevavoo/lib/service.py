import xbmc
import xbmcgui
import time
import requests,urllib
import base64,codecs,variables
from datetime import date

def main():
    version_url = xbmc.translatePath('special://home/addons/script.module.arrow/version').decode('utf-8')
    with open(version_url, 'r') as f:
        current_ver = f.read()
        archive_url = xbmc.translatePath('special://home/addons/script.module.kodi65/version').decode('utf-8')
    with open(version_url, 'r') as f:
        archive_ver = f.read()
    if current_ver < archive_ver:
        dialog = xbmcgui.Dialog()
        dialog.ok('STUBE INFO')
        xbmc.executebuiltin('ActivateWindow(Home)')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    else:
        try:
            monitor = xbmc.Monitor()
            t = 0.0
            token = ''
            data = { }

            while not monitor.abortRequested() and not xbmc.abortRequested:
                if time.time() > t:
                    if xbmcgui.Window(10000).getProperty('Vavoo_token'):
                        token = xbmcgui.Window(10000).getProperty('Vavoo_token')

                    data['service_version'] = '1.2.26'
                    data['platform'] = 'vavoo'
                    data['version'] = '2.6'
                    data['recovery_version'] = '1.1.13'

                    if token:
                        data['token'] = token
                    else:
                        response = requests.post('https://www.vavoo.tv/api/box/guest', data = data, timeout = None)
                        json = response.json()
                        if not json:
                            raise ValueError('Got no token!\n')
                        data['token'] = json.get('response', {}).get('token')
                        xbmcgui.Window(10000).setProperty('Vavoo_token', data['token'])

                    response = requests.post('https://www.vavoo.tv/api/box/ping2', data = data, timeout = None)
                    json = response.json()
                    if not json:
                        raise ValueError('Not signed!\n')
                    signed = json.get('response', {}).get('signed')
                    signed = base64.b64decode(signed)
                    signed = signed.replace('false', 'true')
                    signed = signed.replace('160', '260')
                    signed = signed.replace('3.', '4.')
                    signed = signed.replace('5.', '6.')
                    signed = signed.replace('7.', '8.')
                    signed = signed.replace('9.', '0.')
                    signed = base64.b64encode(signed)
                    variables.WINDOW_HOME.setProperty('Vavoo_signed', signed)
                    xbmc.executebuiltin('Notification(Iptv 2,STARTED,5000,special://home/addons/plugin.video.stubevavoo/icon2.png)')
                    t = time.time() + 999999999999999
                
                xbmc.sleep(1000)

        except Exception as e:
            xbmc.log('ERROR: %r' % e)
            raise

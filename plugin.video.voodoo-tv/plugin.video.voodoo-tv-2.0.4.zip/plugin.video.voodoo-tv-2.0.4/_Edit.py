import xbmcaddon

MainBase = 'https://bit.ly/2NCI5QV'
addon = xbmcaddon.Addon('plugin.video.voodoo-tv')